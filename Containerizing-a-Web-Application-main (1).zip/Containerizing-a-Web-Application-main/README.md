<<<<<<< HEAD
# Containerizing-a-Web-Application

The main objective is to develop a minimal viable product (MVP) of the project management web application using HTML, CSS, and JavaScript.
Additionally, you will containerize this application using Docker to ensure it can be easily deployed and scaled across different environments 
without any issues.
=======
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
>>>>>>> 9e5418bf45e99c2de30fd6328da560f2441d8087
