const NavBar = () => {
    return (
        <>
            <div className="bg-slate-700 p-3 text-2xl font-bold text-white">
                Todo List
            </div>
        </>
    );
}

export default NavBar;